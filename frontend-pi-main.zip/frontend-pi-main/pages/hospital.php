<?php include 'layouts/header.php'; ?>
<div class="container">
    <label for="province" class="w-100">
        <span>Provinsi</span>
        <select name="province" id="province" class="form-select"></select>
    </label>
    <label for="city" id="city-label" class="w-100 d-none">
        <span>Kota</span>
        <select name="city" id="city" class="form-select"></select>
    </label>
    <label for="hospital" id="hospital-label" class="w-100 d-none">
        <span>Rumah Sakit</span>
        <select name="hospital" id="hospital" class="form-select"></select>
    </label>

    <div id="list" class="row justify-content-center mt-5"></div>
</div>

<script>
    const province = document.getElementById('province');
    const city = document.getElementById('city');
    const hospital = document.getElementById('hospital');
    const list = document.getElementById('list');
    const cityLabel = document.getElementById('city-label');
    const hospitalLabel = document.getElementById('hospital-label');

    const getProvince = async () => {
        province.innerHTML = "<option>loading...</option>";
        const url = 'https://rs-bed-covid-api.vercel.app/api/get-provinces';
        const provinces = await fetch(url);
        const provincesJson = await provinces.json();
        let html = "";
        provincesJson.provinces.forEach(province => {
            html += `<option value="${province.id}">${province.name}</option>`;
        });
        province.innerHTML = html;
    }
    getProvince()

    province.addEventListener('change', async () => {
        cityLabel.classList.remove('d-none');
        city.innerHTML = "<option>loading...</option>";
        const url = `https://rs-bed-covid-api.vercel.app/api/get-cities?provinceid=${province.value}`;
        const cities = await fetch(url);
        const citiesJson = await cities.json();
        let html = "";
        citiesJson.cities.forEach(city => {
            html += `<option value="${city.id}">${city.name}</option>`;
        });
        city.innerHTML = html;
    })

    city.addEventListener('change', async () => {
        const url = `https://rs-bed-covid-api.vercel.app/api/get-hospitals?provinceid=${province.value}&cityid=${city.value}&type=1`;
        const hospitals = await fetch(url);
        const hospitalsJson = await hospitals.json();
        let html = "";
        hospitalsJson.hospitals.forEach(hospital => {
            html += `<div class="col-md-3 p-3">
            <div class="card h-100">
               <div class="card-body">
                   <h5 class="card-title">${hospital.name}</h5>
                   <p class="card-text">
                       <ul>
                           <li>Address : ${hospital.address}</li>
                           <li>Phone : ${hospital.phone}</li>
                           <li>Info : ${hospital.info}</li>
                            <a href="#" class="btn btn-${ hospital.bed_availability > 0 ? 'primary' : 'secondary'} w-100">Lanjut</a>

                       </ul>
                   </p>
               </div>
           </div>
            </div>`;
        });
        list.innerHTML = html;
    })
</script>
<?php include 'layouts/footer.php'; ?>