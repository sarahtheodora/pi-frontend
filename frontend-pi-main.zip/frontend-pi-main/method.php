<?php

class Hospital {
    public $koneksi;
    
    public function __construct()
    {
        $this->koneksi = new mysqli("localhost", "root", "", "hospital");
    }
}