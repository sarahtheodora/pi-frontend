<?php

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    switch ($page) {
        case 'home':
            include 'pages/home.php';
            break;
        case 'hospital':
            include 'pages/hospital.php';
            break;

        default:
            include 'pages/home.php';
            break;
    }
} else {
    include 'pages/home.php';
}
